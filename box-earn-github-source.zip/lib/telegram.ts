import crypto from "crypto";
export function validateInitData(initData: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token || !initData) throw new Error("Telegram authentication is not configured");
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) throw new Error("Missing Telegram authentication hash");
  params.delete("hash");
  const dataCheckString = [...params.entries()].sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${k}=${v}`).join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(token).digest();
  const calculated = crypto.createHmac("sha256", secret).update(dataCheckString).digest("hex");
  const a = Buffer.from(calculated, "hex"), b = Buffer.from(hash, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) throw new Error("Invalid Telegram login");
  const authDate = Number(params.get("auth_date") || 0);
  if (!authDate || Date.now()/1000 - authDate > 86400) throw new Error("Telegram login expired");
  const user = JSON.parse(params.get("user") || "{}");
  if (!user.id) throw new Error("Telegram user missing");
  return user as {id:number;first_name:string;last_name?:string;username?:string;photo_url?:string};
}
export function isAdmin(id:number) {
  return (process.env.ADMIN_TELEGRAM_IDS || "").split(",").map(x=>x.trim()).includes(String(id));
}