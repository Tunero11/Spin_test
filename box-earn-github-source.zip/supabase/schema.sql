create table if not exists public.users (
 telegram_id bigint primary key, first_name text not null, username text, photo_url text,
 boxes integer not null default 0 check (boxes >= 0),
 balance_usdt numeric(18,6) not null default 0 check (balance_usdt >= 0),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.box_openings (
 id uuid primary key default gen_random_uuid(), telegram_id bigint not null references public.users(telegram_id),
 reward numeric(18,6) not null check(reward >= 0.005 and reward <= 0.009), created_at timestamptz not null default now()
);
create table if not exists public.app_settings (
 key text primary key, value text not null, updated_by bigint, updated_at timestamptz default now()
);
create table if not exists public.tasks (
 id uuid primary key default gen_random_uuid(), title text not null, description text,
 task_url text, task_type text not null default 'visit', reward_boxes integer not null default 1,
 active boolean not null default true, created_at timestamptz default now()
);
create table if not exists public.task_completions (
 id uuid primary key default gen_random_uuid(), task_id uuid references public.tasks(id),
 telegram_id bigint references public.users(telegram_id), status text not null default 'pending',
 rewarded_at timestamptz, created_at timestamptz default now(),
 unique(task_id,telegram_id)
);
create table if not exists public.referrals (
 id uuid primary key default gen_random_uuid(), referrer_id bigint references public.users(telegram_id),
 referred_id bigint unique references public.users(telegram_id), status text not null default 'pending',
 completed_verified_tasks integer not null default 0, rewarded_at timestamptz, created_at timestamptz default now()
);
create table if not exists public.ad_daily (
 telegram_id bigint references public.users(telegram_id), ad_date date not null,
 verified_count integer not null default 0, claimed boolean not null default false,
 primary key(telegram_id,ad_date)
);
create table if not exists public.withdrawals (
 id uuid primary key default gen_random_uuid(), telegram_id bigint references public.users(telegram_id),
 amount numeric(18,6) not null check(amount >= 0.10), wallet_address text not null,
 network text not null default 'USDT_BEP20', status text not null default 'pending',
 tx_hash text, created_at timestamptz default now(), updated_at timestamptz default now()
);

create or replace function public.open_user_box(p_telegram_id bigint,p_reward numeric)
returns json language plpgsql security definer set search_path=public as $$
declare remaining integer;
begin
 update users set boxes=boxes-1,balance_usdt=balance_usdt+p_reward,updated_at=now()
 where telegram_id=p_telegram_id and boxes>0 returning boxes into remaining;
 if not found then raise exception 'No available boxes'; end if;
 insert into box_openings(telegram_id,reward) values(p_telegram_id,p_reward);
 return json_build_object('boxes',remaining,'reward',p_reward);
end; $$;

-- IMPORTANT: Enable RLS before production and expose no service-role key to clients.
alter table users enable row level security;
alter table box_openings enable row level security;
alter table app_settings enable row level security;
alter table tasks enable row level security;
alter table task_completions enable row level security;
alter table referrals enable row level security;
alter table ad_daily enable row level security;
alter table withdrawals enable row level security;
-- This starter uses the server-side service role key in API routes. Do not create public write policies.
