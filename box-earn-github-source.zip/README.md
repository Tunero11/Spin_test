# BOX EARN — GitHub-ready starter

A Telegram Mini App starter using Next.js, Supabase and Telegram Web Apps authentication.

## Before deploying
The bot token previously pasted into chat is exposed. Revoke it in @BotFather and generate a NEW token. Never commit tokens or `.env` files.

## 1. Create Supabase
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy Project URL and service-role key from Project Settings → API.
4. Keep the service-role key private.

## 2. Run locally
Requires Node.js 20+.

```bash
cp .env.example .env.local
npm install
npm run dev
```

Fill `.env.local` with your Supabase URL, service role key, NEW bot token, bot username, admin Telegram numeric ID, and two public channel usernames.

## 3. Deploy to GitHub and Vercel
1. Create a GitHub repository named `box-earn`.
2. Upload the contents of this folder (not the enclosing folder).
3. Import the repository at https://vercel.com/new.
4. Add every variable from `.env.example` in Vercel → Project → Settings → Environment Variables.
5. Deploy.
6. Set the Telegram bot menu button / Mini App URL to the deployed HTTPS URL using BotFather or Telegram Bot API.

## 4. Telegram channel membership
Add the bot as an administrator in BOTH channels. The bot needs permission to inspect membership. Set `CHANNEL_ONE_USERNAME` and `CHANNEL_TWO_USERNAME` without the @ symbol.

## Current implementation status
Included:
- Responsive Box Earn interface and navigation.
- Telegram `initData` signature validation.
- User upsert and profile display.
- Server-side two-channel membership check endpoint.
- Atomic box opening RPC and $0.005–$0.009 reward generation.
- Database schema for tasks, referrals, daily ads, withdrawals and settings.
- Admin settings API starter with Telegram ID allowlist.

Still needs configuration/development before real-money launch:
- Task-specific verification and reward-claim API.
- Referral deep-link registration and two-verified-task qualification transaction.
- Monetag approved integration and trusted completion callback. The UI intentionally does not count simulated ad views or grant rewards.
- Daily 200-ad claim RPC (one atomic 20-box claim, no partial claims).
- Withdrawal request/admin approval APIs and actual BEP20 payout integration.
- Full admin UI and task/channel management screens.
- Configure Telegram Mini App launch button and test with real Telegram accounts.

## Important security notes
- Never expose `SUPABASE_SERVICE_ROLE_KEY` or `TELEGRAM_BOT_TOKEN` to browser code.
- Set `ADMIN_TELEGRAM_IDS` to your numeric Telegram ID(s), comma-separated.
- This is a development starter, not audited financial software. Test with test accounts and do not accept deposits or promise payouts until the reward, ad verification, withdrawal and anti-abuse flows have been implemented and independently reviewed.
