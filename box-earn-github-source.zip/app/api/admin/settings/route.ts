import {NextRequest,NextResponse} from "next/server";
import {validateInitData,isAdmin} from "@/lib/telegram";
import {db} from "@/lib/supabase";
export async function GET(req:NextRequest){
 try{
  const user=validateInitData(req.headers.get("x-telegram-init-data")||"");
  if(!isAdmin(user.id)) return NextResponse.json({error:"Forbidden"},{status:403});
  const {data,error}=await db.from("app_settings").select("*"); if(error) throw error;
  return NextResponse.json({settings:data});
 }catch(e:any){return NextResponse.json({error:e.message},{status:401});}
}
export async function POST(req:NextRequest){
 try{
  const user=validateInitData(req.headers.get("x-telegram-init-data")||"");
  if(!isAdmin(user.id)) return NextResponse.json({error:"Forbidden"},{status:403});
  const {key,value}=await req.json();
  if(!["channel_one","channel_two","min_withdraw"].includes(key)) throw new Error("Unsupported setting");
  const {error}=await db.from("app_settings").upsert({key,value,updated_by:user.id,updated_at:new Date().toISOString()},{onConflict:"key"});
  if(error) throw error; return NextResponse.json({ok:true});
 }catch(e:any){return NextResponse.json({error:e.message},{status:400});}
}