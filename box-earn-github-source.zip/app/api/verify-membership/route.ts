import { NextRequest, NextResponse } from "next/server";
import { validateInitData } from "@/lib/telegram";
export async function POST(req:NextRequest) {
  try {
    const {initData} = await req.json();
    const user = validateInitData(initData);
    const token = process.env.TELEGRAM_BOT_TOKEN!;
    const names = [process.env.CHANNEL_ONE_USERNAME,process.env.CHANNEL_TWO_USERNAME].filter(Boolean);
    if(names.length !== 2) throw new Error("Admin must configure both channels");
    const results = await Promise.all(names.map(async name=>{
      const r = await fetch(`https://api.telegram.org/bot${token}/getChatMember?chat_id=@${name}&user_id=${user.id}`,{cache:"no-store"});
      const j = await r.json();
      return Boolean(j.ok && ["member","administrator","creator"].includes(j.result?.status));
    }));
    return NextResponse.json({joined:results.every(Boolean),channels:results});
  } catch(e:any) { return NextResponse.json({error:e.message || "Verification failed"},{status:400}); }
}