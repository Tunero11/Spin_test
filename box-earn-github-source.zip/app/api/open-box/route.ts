import { NextRequest,NextResponse } from "next/server";
import { validateInitData } from "@/lib/telegram";
import { db } from "@/lib/supabase";
import crypto from "crypto";
export async function POST(req:NextRequest) {
  try {
    const {initData}=await req.json(); const user=validateInitData(initData);
    const reward=Number((0.005 + crypto.randomInt(0,4001)/1000000).toFixed(6));
    const {data,error}=await db.rpc("open_user_box",{p_telegram_id:user.id,p_reward:reward});
    if(error) throw error;
    return NextResponse.json({reward, result:data});
  } catch(e:any) { return NextResponse.json({error:e.message || "Could not open box"},{status:400}); }
}