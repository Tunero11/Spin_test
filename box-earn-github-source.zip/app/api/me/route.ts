import { NextRequest, NextResponse } from "next/server";
import { validateInitData } from "@/lib/telegram";
import { db } from "@/lib/supabase";
export async function POST(req:NextRequest) {
  try {
    const {initData} = await req.json();
    const user = validateInitData(initData);
    const {data,error} = await db.from("users").upsert({
      telegram_id:user.id, first_name:user.first_name, username:user.username || null,
      photo_url:user.photo_url || null, updated_at:new Date().toISOString()
    },{onConflict:"telegram_id"}).select("telegram_id,first_name,username,photo_url,boxes,balance_usdt").single();
    if(error) throw error;
    return NextResponse.json({user:data});
  } catch(e:any) { return NextResponse.json({error:e.message || "Authentication failed"},{status:401}); }
}